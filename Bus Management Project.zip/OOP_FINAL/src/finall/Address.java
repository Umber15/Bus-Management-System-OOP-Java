package finall;

import java.util.Scanner;

public class Address {
	private String district,tehsil,city,postal_code;
	public void display()
	{
		System.out.println(district+" "+tehsil);
	}
	public String getDistrict()
	{
		return district;
	}
	public String getTehsil()
	{
		return tehsil;
	}
	public String getCity()
	{
		return city;
	}
	public String getPostalCode()
	{
		return postal_code;
	}
	public Address(String d,String t,String c,String p)
	{
		district=d;tehsil=t;city=c;postal_code=p;
	}
	Scanner sc=new Scanner(System.in);
	public void setAddress(String d,String t,String c,String p)
	{
		district=d;tehsil=t;city=c;postal_code=p;
	}

	public void inputAddress()
	{
		System.out.print("\nENTER YOUR DISTRICT : ");
		district=sc.next();
		System.out.print("\nENTER YOUR TEHSIL : ");
		tehsil=sc.next();
		System.out.print("\nENTER YOUR CITY : ");
		city=sc.next();
		System.out.print("\nENTER YOUR POSTAL ADDRESS : ");
		postal_code=sc.next();
		new Address(district,tehsil,city,postal_code);
	}
	public String toString()
	{
		return "ADDRESS "+district+"#"+tehsil+"#"+city+"#"+postal_code+"#";
	}
}
