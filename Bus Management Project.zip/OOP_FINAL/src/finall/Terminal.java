package finall;

public class Terminal {
private String terminal_A="Rawalpindi";
private String terminal_B="Lahore";
private String terminal_C="Karachi";
private String terminal_D="Peshawar";
public String getTerminal_A()
{
	return terminal_A;
}
public String getTerminal_B()
{
	return terminal_B;
}
public String getTerminal_C()
{
	return terminal_C;
}
public String getTerminal_D()
{
	return terminal_D;
}

}
