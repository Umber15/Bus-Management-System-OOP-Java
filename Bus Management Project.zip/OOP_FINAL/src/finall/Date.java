package finall;

import java.util.Scanner;

public class Date {
	Scanner sc=new Scanner(System.in);
public int year,month,day;
public Date(int y,int m,int d)
{
	year=y;month=m;day=d;
}
public int getYear()
{
	return year;
}
public int getMonth()
{
	return month;
}
public int getDay()
{
	return day;
}
public void inputDate()
{
	System.out.print("\nENTER DAY FOR TICKET RESERVATION : ");
	day=sc.nextInt();
	while(day<1&&day>31)
	{
		System.out.print("INVALID DATE , RE-ENTER  ");
		day=sc.nextInt();
	}
	System.out.print("\nENTER MONTH FOR TICKET RESERVATION: ");
	month=sc.nextInt();
	while(month<1&&month>12)
	{
		System.out.print("INVALID MONTH , RE-ENTER  ");
		month=sc.nextInt();
	}
	System.out.print("\nENTER YEAR FOR TICKET RESERVATION : ");
	year=sc.nextInt();
	while(year<2000)
	{
		System.out.print("INVALID YEAR , RE-ENTER  ");
		year=sc.nextInt();
	}
	new Date(year,month,day);
}
}
