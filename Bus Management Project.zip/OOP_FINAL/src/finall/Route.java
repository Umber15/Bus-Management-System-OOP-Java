package finall;

public class Route extends Terminal
{
	Terminal t1=new Terminal();
	private String route1=t1.getTerminal_A()+"to "+t1.getTerminal_B()+" and vice versa";
	public String route2=t1.getTerminal_A()+"to "+t1.getTerminal_D()+" and vice versa";
	public String route3=t1.getTerminal_C()+"to "+t1.getTerminal_D()+" and vice versa";
	public String route4=t1.getTerminal_D()+"to "+t1.getTerminal_B()+" and vice versa";
	public String getRoute1()
	{
		return route1;
	}
	public String getRoute()
	{
		return route1;
	}
	public void routes() 
	{
	System.out.print("------------------BUS ROUTES---------------");
	System.out.println("1. "+route1);
	System.out.println("2. "+route2);
	System.out.println("3. "+route3);
	System.out.println("4. "+route4);
	}
}
