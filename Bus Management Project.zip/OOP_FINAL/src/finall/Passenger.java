package finall;

import java.util.Scanner;

public class Passenger {
public String name;
public String phno;
public char gender;
public Passenger(String n,String p,char g)
{
	name=n;
	phno=p;
	gender=g;
}
public void inputPassenger()
{
	Scanner sc=new Scanner(System.in);
	System.out.print("ENTER NAME : ");
	name=sc.next();
	System.out.print("ENTER YOUR PHONE-NUMBER : ");
	phno=sc.next();
	System.out.print("ENTER GENDER LIKE (M,F)");
	gender=sc.next().charAt(0);	
	System.out.print("\n");
	new Passenger(name,phno,gender);
}
public String toString()
{
	return name+"#"+phno+"#"+gender+"\n";
}

}
