package finall;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Ticket t1=new Ticket();
		Admin a1=new Admin();
		int choice;
	 Address address=new Address("rg","wry","rhtw","wryet");
		Driver d1=new Driver(0,"","",address,false);
		Driver d2=new Driver(0,"","",address,false);
		Driver d3=new Driver(0,"","",address,false);
		Driver d4=new Driver(0,"","",address,false);
		
		
		FileHandler file=new FileHandler("C:\\Users\\PC\\Desktop\\Driver.txt",false);
			String data=file.read();
			if(data.equals(""))
			{
				d1.addDriver();
				d2.addDriver();
				d3.addDriver();
				d4.addDriver();
			}
			
		do {
			
			a1.menu0();
			choice=0;
			Scanner sc=new Scanner(System.in);
			choice=sc.nextInt();
			if(choice==1)
			{
				a1.menu();
				int need=sc.nextInt();
				if(need==1)
				{
					a1.chooseClass();
					int userChoice=sc.nextInt();
					if(userChoice==1)
					{
						
						t1.bookTicketBus1Bussiness();
					}
					else if(userChoice==2)
					{
						t1.bookTicketBus1Economic();
					}
					else if(userChoice==3)
					{
						t1.bookTicketBus1Local();
					}
					else
					{
						System.out.println("INVALID INPUT :(");
					}
				}
				
				else if(need==2)
				{
					a1.chooseClass();
					int userChoice=sc.nextInt();
					if(userChoice==1)
					{
						t1.bookTicketBus2Bussiness();
					}
					else if(userChoice==2)
					{
						t1.bookTicketBus2Economic();
					}
					else if(userChoice==3)
					{
						t1.bookTicketBus2Local();
					}
					else
					{
						System.out.println("INVALID INPUT :(");
					}
				}
				
				else if(need==3)
				{
					a1.chooseClass();
					int userChoice=sc.nextInt();
					if(userChoice==1)
					{
						t1.bookTicketBus3Bussiness();
					}
					else if(userChoice==2)
					{
						t1.bookTicketBus3Economic();
					}
					else if(userChoice==3)
					{
						t1.bookTicketBus3Local();
					}
					else
					{
						System.out.println("INVALID INPUT :(");
					}
				}
				
				else if(need==4)
				{
					a1.chooseClass();
					int userChoice=sc.nextInt();
					if(userChoice==1)
					{
						t1.bookTicketBus4Bussiness();
					}
					else if(userChoice==2)
					{
						t1.bookTicketBus4Economic();
					}
					else if(userChoice==3)
					{
						t1.bookTicketBus4Local();
					}
					else
					{
						System.out.println("INVALID INPUT :(");
					}
				}
				
				else 
				{
					System.out.println("INVALID INPUT :(");
				}
			}
			
			
			else if(choice==2)
			{
				a1.deleteMenu();
				int userNeed=sc.nextInt();
				
				//bus 1 
				if(userNeed==1)
				{
					a1.chooseTime();
					int need=sc.nextInt();
					if(need==1)
					{
						a1.deleteClass();
						int type=sc.nextInt();
						if(type==1)
						{
							t1.deleteBus1_M_B();
						}
						else if(type==2)
						{
							t1.deleteBus1_M_E();
						}
						else if(type==3)
						{
							t1.deleteBus1_M_L();
						}
						else
						{
							System.out.println("INVALID INPUT :(");
						}
					}
					else if(need==2)
					{
						a1.deleteClass();
						int type=sc.nextInt();
						if(type==1)
						{
							t1.deleteBus1_E_B();
						}
						else if(type==2)
						{
							t1.deleteBus1_E_E();
						}
						else if(type==3)
						{
							t1.deleteBus1_E_L();
						}
						else
						{
							System.out.println("INVALID INPUT :(");
						}
					}
				}
				
				//bus 2
				else if(userNeed==2)
				{
					a1.chooseTime();
					int need=sc.nextInt();
					if(need==1)
					{
						a1.deleteClass();
						int type=sc.nextInt();
						if(type==1)
						{
							t1.deleteBus2_M_B();
						}
						else if(type==2)
						{
							t1.deleteBus2_M_E();
						}
						else if(type==3)
						{
							t1.deleteBus2_M_L();
						}
						else
						{
							System.out.println("INVALID INPUT :(");
						}
					}
					else if(need==2)
					{
						a1.deleteClass();
						int type=sc.nextInt();
						if(type==1)
						{
							t1.deleteBus2_E_B();
						}
						else if(type==2)
						{
							t1.deleteBus2_E_E();
						}
						else if(type==3)
						{
							t1.deleteBus2_E_L();
						}
						else
						{
							System.out.println("INVALID INPUT :(");
						}
					}
				}
				
				//bus 3
				else if(userNeed==1)
				{
					a1.chooseTime();
					int need=sc.nextInt();
					if(need==1)
					{
						a1.deleteClass();
						int type=sc.nextInt();
						if(type==1)
						{
							t1.deleteBus3_M_B();
						}
						else if(type==2)
						{
							t1.deleteBus3_M_E();
						}
						else if(type==3)
						{
							t1.deleteBus3_M_L();
						}
						else
						{
							System.out.println("INVALID INPUT :(");
						}
					}
					else if(need==2)
					{
						a1.deleteClass();
						int type=sc.nextInt();
						if(type==1)
						{
							t1.deleteBus3_E_B();
						}
						else if(type==2)
						{
							t1.deleteBus3_E_E();
						}
						else if(type==3)
						{
							t1.deleteBus3_E_L();
						}
						else
						{
							System.out.println("INVALID INPUT :(");
						}
					}
				}
				
				//bus 4
				else if(userNeed==1)
				{
					a1.chooseTime();
					int need=sc.nextInt();
					if(need==1)
					{
						a1.deleteClass();
						int type=sc.nextInt();
						if(type==1)
						{
							t1.deleteBus4_M_B();
						}
						else if(type==2)
						{
							t1.deleteBus4_M_E();
						}
						else if(type==3)
						{
							t1.deleteBus4_M_L();
						}
						else
						{
							System.out.println("INVALID INPUT :(");
						}
					}
					else if(need==2)
					{
						a1.deleteClass();
						int type=sc.nextInt();
						if(type==1)
						{
							t1.deleteBus4_E_B();
						}
						else if(type==2)
						{
							t1.deleteBus4_E_E();
						}
						else if(type==3)
						{
							t1.deleteBus4_E_L();
						}
						else
						{
							System.out.println("INVALID INPUT :(");
						}
					}
				}
			}
			else if(choice==3)
			{
				System.out.println("EXISTING..........");
			}
			else
			{
					System.out.println("INVALID INPUT :(");
			}
		}while(choice!=3);

	}

}
