package finall;

import java.io.FileReader;
import java.io.FileWriter;

public class FileHandler {
	boolean app;String path;
	public FileHandler(String path,boolean app)
	{
		this.path=path;
		this.app=app;
	}
	public void write(String data)
	{
		try {
			FileWriter writer;
			writer=new FileWriter(path,app);
				writer.write(data);
				writer.close();
		}
		catch(Exception ex)
		{
			//System.out.print("invalid");
		}
	}
	public String read()
	{
		String data="";
		try {
			int ascii;
			FileReader reader;
			reader=new FileReader(path);
			while(true)
			{
				ascii=reader.read();
				if(ascii==-1)
				{
				break;	
				}
				data=data+(char)ascii;
			}
			reader.close();
		}
		catch(Exception ex)
		{
			//System.out.print("invalid");
		}
	return data;
}
}