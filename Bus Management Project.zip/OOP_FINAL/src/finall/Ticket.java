package finall;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.util.Scanner;



public class Ticket extends Buss{
	public int ticketId;
	public static int auto_ticket;
	static
	{
		auto_ticket=20;
	}
	
	public Ticket()
	{
		ticketId=auto_ticket;
		auto_ticket++;
	}
	public Ticket(String data)
	{
		String rows[]=data.split("#");
		ticketId=Integer.parseInt(rows[0]);
		ticketType=rows[1];
		date.day=Integer.parseInt(rows[2]);
		date.month=Integer.parseInt(rows[3]);
		date.year=Integer.parseInt(rows[4]);
	}
	public Ticket[] getAllTickets(String path)
	{
		FileHandler file=new FileHandler(path,false);
		String filedata=file.read();
		if(filedata.equals(""))
		{
			return null;
		}
		String rows[]=filedata.split("\n");
	    Ticket []data=new Ticket[rows.length];
		for(int i=0;i<rows.length;i++)
		{
			data[i]=new Ticket(rows[i]);
		}
		return data;
	}
	
	public Date date=new Date(1,1,1);
	public String ticketType;
	public Passenger p=new Passenger("","",'f');
	Buss bus1=new Buss();
	Buss bus2=new Buss();
	Buss bus3=new Buss();
	Buss bus4=new Buss();
	
	
	public Date reservationDate=new Date(1,1,1);
	
	public String toString()
	{
		return ticketId+"#"+ticketType+"#"+reservationDate.getDay()+"#"+
	    reservationDate.getMonth()+"#"+reservationDate.getYear()+"#";
	}
	
	public void deleteBus1_M_B()
	{
		System.out.println("ENTER ID FOR DELETION ");
		Scanner sc=new Scanner(System.in);
			int id=sc.nextInt();
		Ticket arr[]=getAllTickets("C:\\Users\\PC\\Desktop\\BUS 1 MORNING_B.txt");
		boolean flag=false;
		
		if(arr[0]==null)
		{
			System.out.println("NO TICKET ");
		}
		else 
		{
			for(int i=0;i<arr.length;i++)
			{
				if(arr[i].ticketId==id)
				{
						flag=true;
				}
				if(arr[i].ticketId!=id)
				{
					
					String data=arr[i].toString();
					FileHandler file=new FileHandler("C:\\Users\\PC\\Desktop\\BUS 1 MORNING_B.txt",true);
					file.write(data); 
				}
					
			}
		}
		if(flag==true)
		{
			System.out.println("TICKET CANCELED SUCCESSFULLY");
	    }
		else {
	System.out.println("TICKET ID DOESN'T MATCH ");
		}
	}
	
	public void deleteBus1_E_B()
	{
		System.out.println("ENTER ID FOR DELETION ");
		Scanner sc=new Scanner(System.in);
			int id=sc.nextInt();
		Ticket arr[]=getAllTickets("C:\\Users\\PC\\Desktop\\BUS 1 EVENING_B.txt");
		boolean flag=false;
		
		if(arr[0]==null)
		{
			System.out.println("NO TICKET ");
		}
		else 
		{
			for(int i=0;i<arr.length;i++)
			{
				if(arr[i].ticketId==id)
				{
						flag=true;
				}
				if(arr[i].ticketId!=id)
				{
					
					String data=arr[i].toString();
					FileHandler file=new FileHandler("C:\\Users\\PC\\Desktop\\BUS 1 EVENING_B.txt",true);
					file.write(data); 
				}
					
			}
		}
		if(flag==true)
		{
			System.out.println("TICKET CANCELED SUCCESSFULLY");
	    }
		else {
	System.out.println("TICKET ID DOESN'T MATCH ");
		}
	}
	
	public void deleteBus1_M_E()
	{
		System.out.println("ENTER ID FOR DELETION ");
		Scanner sc=new Scanner(System.in);
			int id=sc.nextInt();
		Ticket arr[]=getAllTickets("C:\\Users\\PC\\Desktop\\BUS 1 MORNING_E.txt");
		boolean flag=false;
		
		if(arr[0]==null)
		{
			System.out.println("NO TICKET ");
		}
		else 
		{
			for(int i=0;i<arr.length;i++)
			{
				if(arr[i].ticketId==id)
				{
						flag=true;
				}
				if(arr[i].ticketId!=id)
				{
					
					String data=arr[i].toString();
					FileHandler file=new FileHandler("C:\\Users\\PC\\Desktop\\BUS 1 MORNING_E.txt",true);
					file.write(data); 
				}
					
			}
		}
		if(flag==true)
		{
			System.out.println("TICKET CANCELED SUCCESSFULLY");
	    }
		else {
	System.out.println("TICKET ID DOESN'T MATCH ");
		}
	}
	
	public void deleteBus1_E_E()
	{
		System.out.println("ENTER ID FOR DELETION ");
		Scanner sc=new Scanner(System.in);
			int id=sc.nextInt();
		Ticket arr[]=getAllTickets("C:\\Users\\PC\\Desktop\\BUS 1 EVENING_E.txt");
		boolean flag=false;
		
		if(arr[0]==null)
		{
			System.out.println("NO TICKET ");
		}
		else 
		{
			for(int i=0;i<arr.length;i++)
			{
				if(arr[i].ticketId==id)
				{
						flag=true;
				}
				if(arr[i].ticketId!=id)
				{
					
					String data=arr[i].toString();
					FileHandler file=new FileHandler("C:\\Users\\PC\\Desktop\\BUS 1 EVENING_E.txt",true);
					file.write(data); 
				}
					
			}
		}
		if(flag==true)
		{
			System.out.println("TICKET CANCELED SUCCESSFULLY");
	    }
		else {
	System.out.println("TICKET ID DOESN'T MATCH ");
		}
	}
	
	public void deleteBus1_M_L()
	{
		System.out.println("ENTER ID FOR DELETION ");
		Scanner sc=new Scanner(System.in);
			int id=sc.nextInt();
		Ticket arr[]=getAllTickets("C:\\Users\\PC\\Desktop\\BUS 1 MORNING_L.txt");
		boolean flag=false;
		
		if(arr[0]==null)
		{
			System.out.println("NO TICKET ");
		}
		else 
		{
			for(int i=0;i<arr.length;i++)
			{
				if(arr[i].ticketId==id)
				{
						flag=true;
				}
				if(arr[i].ticketId!=id)
				{
					
					String data=arr[i].toString();
					FileHandler file=new FileHandler("C:\\Users\\PC\\Desktop\\BUS 1 MORNING_L.txt",true);
					file.write(data); 
				}
					
			}
		}
		if(flag==true)
		{
			System.out.println("TICKET CANCELED SUCCESSFULLY");
	    }
		else {
	System.out.println("TICKET ID DOESN'T MATCH ");
		}
	}
	
		
	public void deleteBus1_E_L()
	{
		System.out.println("ENTER ID FOR DELETION ");
		Scanner sc=new Scanner(System.in);
			int id=sc.nextInt();
		Ticket arr[]=getAllTickets("C:\\Users\\PC\\Desktop\\BUS 1 EVENING_L.txt");
		boolean flag=false;
		
		if(arr[0]==null)
		{
			System.out.println("NO TICKET ");
		}
		else 
		{
			for(int i=0;i<arr.length;i++)
			{
				if(arr[i].ticketId==id)
				{
						flag=true;
				}
				if(arr[i].ticketId!=id)
				{
					
					String data=arr[i].toString();
					FileHandler file=new FileHandler("C:\\Users\\PC\\Desktop\\BUS 1 EVENING_L.txt",true);
					file.write(data); 
				}
					
			}
		}
		if(flag==true)
		{
			System.out.println("TICKET CANCELED SUCCESSFULLY");
	    }
		else {
	System.out.println("TICKET ID DOESN'T MATCH ");
		}
	}
	
	
	public void deleteBus2_M_B()
	{
		System.out.println("ENTER ID FOR DELETION ");
		Scanner sc=new Scanner(System.in);
			int id=sc.nextInt();
		Ticket arr[]=getAllTickets("C:\\Users\\PC\\Desktop\\BUS 2 MORNING_B.txt");
		boolean flag=false;
		
		if(arr[0]==null)
		{
			System.out.println("NO TICKET ");
		}
		else 
		{
			for(int i=0;i<arr.length;i++)
			{
				if(arr[i].ticketId==id)
				{
						flag=true;
				}
				if(arr[i].ticketId!=id)
				{
					
					String data=arr[i].toString();
					FileHandler file=new FileHandler("C:\\Users\\PC\\Desktop\\BUS 2 MORNING_B.txt",true);
					file.write(data); 
				}
					
			}
		}
		if(flag==true)
		{
			System.out.println("TICKET CANCELED SUCCESSFULLY");
	    }
		else {
	System.out.println("TICKET ID DOESN'T MATCH ");
		}
	}
	
	
	public void deleteBus2_E_B()
	{
		System.out.println("ENTER ID FOR DELETION ");
		Scanner sc=new Scanner(System.in);
			int id=sc.nextInt();
		Ticket arr[]=getAllTickets("C:\\Users\\PC\\Desktop\\BUS 2 EVENING_B.txt");
		boolean flag=false;
		
		if(arr[0]==null)
		{
			System.out.println("NO TICKET ");
		}
		else 
		{
			for(int i=0;i<arr.length;i++)
			{
				if(arr[i].ticketId==id)
				{
						flag=true;
				}
				if(arr[i].ticketId!=id)
				{
					
					String data=arr[i].toString();
					FileHandler file=new FileHandler("C:\\Users\\PC\\Desktop\\BUS 2 EVENING_B.txt",true);
					file.write(data); 
				}
					
			}
		}
		if(flag==true)
		{
			System.out.println("TICKET CANCELED SUCCESSFULLY");
	    }
		else {
	System.out.println("TICKET ID DOESN'T MATCH ");
		}
	}
	
	
	public void deleteBus2_M_E()
	{
		System.out.println("ENTER ID FOR DELETION ");
		Scanner sc=new Scanner(System.in);
			int id=sc.nextInt();
		Ticket arr[]=getAllTickets("C:\\Users\\PC\\Desktop\\BUS 2 MORNING_E.txt");
		boolean flag=false;
		
		if(arr[0]==null)
		{
			System.out.println("NO TICKET ");
		}
		else 
		{
			for(int i=0;i<arr.length;i++)
			{
				if(arr[i].ticketId==id)
				{
						flag=true;
				}
				if(arr[i].ticketId!=id)
				{
					
					String data=arr[i].toString();
					FileHandler file=new FileHandler("C:\\Users\\PC\\Desktop\\BUS 2 MORNING_E.txt",true);
					file.write(data); 
				}
					
			}
		}
		if(flag==true)
		{
			System.out.println("TICKET CANCELED SUCCESSFULLY");
	    }
		else {
	System.out.println("TICKET ID DOESN'T MATCH ");
		}
	}


	public void deleteBus2_E_E()
	{
		System.out.println("ENTER ID FOR DELETION ");
		Scanner sc=new Scanner(System.in);
			int id=sc.nextInt();
		Ticket arr[]=getAllTickets("C:\\Users\\PC\\Desktop\\BUS 2 EVENING_E.txt");
		boolean flag=false;
		
		if(arr[0]==null)
		{
			System.out.println("NO TICKET ");
		}
		else 
		{
			for(int i=0;i<arr.length;i++)
			{
				if(arr[i].ticketId==id)
				{
						flag=true;
				}
				if(arr[i].ticketId!=id)
				{
					
					String data=arr[i].toString();
					FileHandler file=new FileHandler("C:\\Users\\PC\\Desktop\\BUS 2 EVENING_E.txt",true);
					file.write(data); 
				}
					
			}
		}
		if(flag==true)
		{
			System.out.println("TICKET CANCELED SUCCESSFULLY");
	    }
		else {
	System.out.println("TICKET ID DOESN'T MATCH ");
		}
	}
	
	
	public void deleteBus2_M_L()
	{
		System.out.println("ENTER ID FOR DELETION ");
		Scanner sc=new Scanner(System.in);
			int id=sc.nextInt();
		Ticket arr[]=getAllTickets("C:\\Users\\PC\\Desktop\\BUS 2 MORNING_L.txt");
		boolean flag=false;
		
		if(arr[0]==null)
		{
			System.out.println("NO TICKET ");
		}
		else 
		{
			for(int i=0;i<arr.length;i++)
			{
				if(arr[i].ticketId==id)
				{
						flag=true;
				}
				if(arr[i].ticketId!=id)
				{
					
					String data=arr[i].toString();
					FileHandler file=new FileHandler("C:\\Users\\PC\\Desktop\\BUS 2 MORNING_L.txt",true);
					file.write(data); 
				}
					
			}
		}
		if(flag==true)
		{
			System.out.println("TICKET CANCELED SUCCESSFULLY");
	    }
		else {
	System.out.println("TICKET ID DOESN'T MATCH ");
		}
	}
	


	public void deleteBus2_E_L()
	{
		System.out.println("ENTER ID FOR DELETION ");
		Scanner sc=new Scanner(System.in);
			int id=sc.nextInt();
		Ticket arr[]=getAllTickets("C:\\Users\\PC\\Desktop\\BUS 2 EVENING_L.txt");
		boolean flag=false;
		
		if(arr[0]==null)
		{
			System.out.println("NO TICKET ");
		}
		else 
		{
			for(int i=0;i<arr.length;i++)
			{
				if(arr[i].ticketId==id)
				{
						flag=true;
				}
				if(arr[i].ticketId!=id)
				{
					
					String data=arr[i].toString();
					FileHandler file=new FileHandler("C:\\Users\\PC\\Desktop\\BUS 2 EVENING_L.txt",true);
					file.write(data); 
				}
					
			}
		}
		if(flag==true)
		{
			System.out.println("TICKET CANCELED SUCCESSFULLY");
	    }
		else {
	System.out.println("TICKET ID DOESN'T MATCH ");
		}
	}
	
	
	public void deleteBus3_M_B()
	{
		System.out.println("ENTER ID FOR DELETION ");
		Scanner sc=new Scanner(System.in);
			int id=sc.nextInt();
		Ticket arr[]=getAllTickets("C:\\Users\\PC\\Desktop\\BUS 3 MORNING_B.txt");
		boolean flag=false;
		
		if(arr[0]==null)
		{
			System.out.println("NO TICKET ");
		}
		else 
		{
			for(int i=0;i<arr.length;i++)
			{
				if(arr[i].ticketId==id)
				{
						flag=true;
				}
				if(arr[i].ticketId!=id)
				{
					
					String data=arr[i].toString();
					FileHandler file=new FileHandler("C:\\Users\\PC\\Desktop\\BUS 3 MORNING_B.txt",true);
					file.write(data); 
				}
					
			}
		}
		if(flag==true)
		{
			System.out.println("TICKET CANCELED SUCCESSFULLY");
	    }
		else {
	System.out.println("TICKET ID DOESN'T MATCH ");
		}
	}
	
	
	public void deleteBus3_E_B()
	{
		System.out.println("ENTER ID FOR DELETION ");
		Scanner sc=new Scanner(System.in);
			int id=sc.nextInt();
		Ticket arr[]=getAllTickets("C:\\Users\\PC\\Desktop\\BUS 3 EVENING_B.txt");
		boolean flag=false;
		
		if(arr[0]==null)
		{
			System.out.println("NO TICKET ");
		}
		else 
		{
			for(int i=0;i<arr.length;i++)
			{
				if(arr[i].ticketId==id)
				{
						flag=true;
				}
				if(arr[i].ticketId!=id)
				{
					
					String data=arr[i].toString();
					FileHandler file=new FileHandler("C:\\Users\\PC\\Desktop\\BUS 3 EVENING_B.txt",true);
					file.write(data); 
				}
					
			}
		}
		if(flag==true)
		{
			System.out.println("TICKET CANCELED SUCCESSFULLY");
	    }
		else {
	System.out.println("TICKET ID DOESN'T MATCH ");
		}
	}
	
	
		public void deleteBus3_M_E()
	{
		System.out.println("ENTER ID FOR DELETION ");
		Scanner sc=new Scanner(System.in);
			int id=sc.nextInt();
		Ticket arr[]=getAllTickets("C:\\Users\\PC\\Desktop\\BUS 3 MORNING_E.txt");
		boolean flag=false;
		
		if(arr[0]==null)
		{
			System.out.println("NO TICKET ");
		}
		else 
		{
			for(int i=0;i<arr.length;i++)
			{
				if(arr[i].ticketId==id)
				{
						flag=true;
				}
				if(arr[i].ticketId!=id)
				{
					
					String data=arr[i].toString();
					FileHandler file=new FileHandler("C:\\Users\\PC\\Desktop\\BUS 3 MORNING_E.txt",true);
					file.write(data); 
				}
					
			}
		}
		if(flag==true)
		{
			System.out.println("TICKET CANCELED SUCCESSFULLY");
	    }
		else {
	System.out.println("TICKET ID DOESN'T MATCH ");
		}
	}
	
		
	public void deleteBus3_E_E()
	{
		System.out.println("ENTER ID FOR DELETION ");
		Scanner sc=new Scanner(System.in);
			int id=sc.nextInt();
		Ticket arr[]=getAllTickets("C:\\Users\\PC\\Desktop\\BUS 3 EVENING_E.txt");
		boolean flag=false;
		
		if(arr[0]==null)
		{
			System.out.println("NO TICKET ");
		}
		else 
		{
			for(int i=0;i<arr.length;i++)
			{
				if(arr[i].ticketId==id)
				{
						flag=true;
				}
				if(arr[i].ticketId!=id)
				{
					
					String data=arr[i].toString();
					FileHandler file=new FileHandler("C:\\Users\\PC\\Desktop\\BUS 3 EVENING_E.txt",true);
					file.write(data); 
				}
					
			}
		}
		if(flag==true)
		{
			System.out.println("TICKET CANCELED SUCCESSFULLY");
	    }
		else {
	System.out.println("TICKET ID DOESN'T MATCH ");
		}
	}
	
	
	public void deleteBus3_M_L()
	{
		System.out.println("ENTER ID FOR DELETION ");
		Scanner sc=new Scanner(System.in);
			int id=sc.nextInt();
		Ticket arr[]=getAllTickets("C:\\Users\\PC\\Desktop\\BUS 3 MORNING_L.txt");
		boolean flag=false;
		
		if(arr[0]==null)
		{
			System.out.println("NO TICKET ");
		}
		else 
		{
			for(int i=0;i<arr.length;i++)
			{
				if(arr[i].ticketId==id)
				{
						flag=true;
				}
				if(arr[i].ticketId!=id)
				{
					
					String data=arr[i].toString();
					FileHandler file=new FileHandler("C:\\Users\\PC\\Desktop\\BUS 3 MORNING_L.txt",true);
					file.write(data); 
				}
					
			}
		}
		if(flag==true)
		{
			System.out.println("TICKET CANCELED SUCCESSFULLY");
	    }
		else {
	System.out.println("TICKET ID DOESN'T MATCH ");
		}
	}
	
	public void deleteBus3_E_L()
	{
		System.out.println("ENTER ID FOR DELETION ");
		Scanner sc=new Scanner(System.in);
			int id=sc.nextInt();
		Ticket arr[]=getAllTickets("C:\\Users\\PC\\Desktop\\BUS 3 EVENING_L.txt");
		boolean flag=false;
		
		if(arr[0]==null)
		{
			System.out.println("NO TICKET ");
		}
		else 
		{
			for(int i=0;i<arr.length;i++)
			{
				if(arr[i].ticketId==id)
				{
						flag=true;
				}
				if(arr[i].ticketId!=id)
				{
					
					String data=arr[i].toString();
					FileHandler file=new FileHandler("C:\\Users\\PC\\Desktop\\BUS 3 EVENING_L.txt",true);
					file.write(data); 
				}
					
			}
		}
		if(flag==true)
		{
			System.out.println("TICKET CANCELED SUCCESSFULLY");
	    }
		else {
	System.out.println("TICKET ID DOESN'T MATCH ");
		}
	}
	
	
	
	public void deleteBus4_M_B()
	{
		System.out.println("ENTER ID FOR DELETION ");
		Scanner sc=new Scanner(System.in);
			int id=sc.nextInt();
		Ticket arr[]=getAllTickets("C:\\Users\\PC\\Desktop\\BUS 4 MORNING_B.txt");
		boolean flag=false;
		
		if(arr[0]==null)
		{
			System.out.println("NO TICKET ");
		}
		else 
		{
			for(int i=0;i<arr.length;i++)
			{
				if(arr[i].ticketId==id)
				{
						flag=true;
				}
				if(arr[i].ticketId!=id)
				{
					
					String data=arr[i].toString();
					FileHandler file=new FileHandler("C:\\Users\\PC\\Desktop\\BUS 4 MORNING_B.txt",true);
					file.write(data); 
				}
					
			}
		}
		if(flag==true)
		{
			System.out.println("TICKET CANCELED SUCCESSFULLY");
	    }
		else {
	System.out.println("TICKET ID DOESN'T MATCH ");
		}
	}


	public void deleteBus4_E_B()
	{
		System.out.println("ENTER ID FOR DELETION ");
		Scanner sc=new Scanner(System.in);
			int id=sc.nextInt();
		Ticket arr[]=getAllTickets("C:\\Users\\PC\\Desktop\\BUS 4 EVENING_B.txt");
		boolean flag=false;
		
		if(arr[0]==null)
		{
			System.out.println("NO TICKET ");
		}
		else 
		{
			for(int i=0;i<arr.length;i++)
			{
				if(arr[i].ticketId==id)
				{
						flag=true;
				}
				if(arr[i].ticketId!=id)
				{
					
					String data=arr[i].toString();
					FileHandler file=new FileHandler("C:\\Users\\PC\\Desktop\\BUS 4 EVENING_B.txt",true);
					file.write(data); 
				}
					
			}
		}
		if(flag==true)
		{
			System.out.println("TICKET CANCELED SUCCESSFULLY");
	    }
		else {
	System.out.println("TICKET ID DOESN'T MATCH ");
		}
	}
	
	
	public void deleteBus4_M_E()
	{
		System.out.println("ENTER ID FOR DELETION ");
		Scanner sc=new Scanner(System.in);
			int id=sc.nextInt();
		Ticket arr[]=getAllTickets("C:\\Users\\PC\\Desktop\\BUS 4 MORNING_E.txt");
		boolean flag=false;
		
		if(arr[0]==null)
		{
			System.out.println("NO TICKET ");
		}
		else 
		{
			for(int i=0;i<arr.length;i++)
			{
				if(arr[i].ticketId==id)
				{
						flag=true;
				}
				if(arr[i].ticketId!=id)
				{
					
					String data=arr[i].toString();
					FileHandler file=new FileHandler("C:\\Users\\PC\\Desktop\\BUS 4 MORNING_E.txt",true);
					file.write(data); 
				}
					
			}
		}
		if(flag==true)
		{
			System.out.println("TICKET CANCELED SUCCESSFULLY");
	    }
		else {
	System.out.println("TICKET ID DOESN'T MATCH ");
		}
	}
	
	
	
	public void deleteBus4_E_E()
	{
		System.out.println("ENTER ID FOR DELETION ");
		Scanner sc=new Scanner(System.in);
			int id=sc.nextInt();
		Ticket arr[]=getAllTickets("C:\\Users\\PC\\Desktop\\BUS 4 EVENING_E.txt");
		boolean flag=false;
		
		if(arr[0]==null)
		{
			System.out.println("NO TICKET ");
		}
		else 
		{
			for(int i=0;i<arr.length;i++)
			{
				if(arr[i].ticketId==id)
				{
						flag=true;
				}
				if(arr[i].ticketId!=id)
				{
					
					String data=arr[i].toString();
					FileHandler file=new FileHandler("C:\\Users\\PC\\Desktop\\BUS 4 EVENING_E.txt",true);
					file.write(data); 
				}
					
			}
		}
		if(flag==true)
		{
			System.out.println("TICKET CANCELED SUCCESSFULLY");
	    }
		else {
	System.out.println("TICKET ID DOESN'T MATCH ");
		}
	}
	
	
	public void deleteBus4_M_L()
	{
		System.out.println("ENTER ID FOR DELETION ");
		Scanner sc=new Scanner(System.in);
			int id=sc.nextInt();
		Ticket arr[]=getAllTickets("C:\\Users\\PC\\Desktop\\BUS 4 MORNING_L.txt");
		boolean flag=false;
		
		if(arr[0]==null)
		{
			System.out.println("NO TICKET ");
		}
		else 
		{
			for(int i=0;i<arr.length;i++)
			{
				if(arr[i].ticketId==id)
				{
						flag=true;
				}
				if(arr[i].ticketId!=id)
				{
					
					String data=arr[i].toString();
					FileHandler file=new FileHandler("C:\\Users\\PC\\Desktop\\BUS 4 MORNING_L.txt",true);
					file.write(data); 
				}
					
			}
		}
		if(flag==true)
		{
			System.out.println("TICKET CANCELED SUCCESSFULLY");
	    }
		else {
	System.out.println("TICKET ID DOESN'T MATCH ");
		}
	}
	
	
	public void deleteBus4_E_L()
	{
		System.out.println("ENTER ID FOR DELETION ");
		Scanner sc=new Scanner(System.in);
			int id=sc.nextInt();
		Ticket arr[]=getAllTickets("C:\\Users\\PC\\Desktop\\BUS 4 EVENING_L.txt");
		boolean flag=false;
		
		if(arr[0]==null)
		{
			System.out.println("NO TICKET ");
		}
		else 
		{
			for(int i=0;i<arr.length;i++)
			{
				if(arr[i].ticketId==id)
				{
						flag=true;
				}
				if(arr[i].ticketId!=id)
				{
					
					String data=arr[i].toString();
					FileHandler file=new FileHandler("C:\\Users\\PC\\Desktop\\BUS 4 EVENING_L.txt",true);
					file.write(data); 
				}
					
			}
		}
		if(flag==true)
		{
			System.out.println("TICKET CANCELED SUCCESSFULLY");
	    }
		else {
	System.out.println("TICKET ID DOESN'T MATCH ");
		}
	}
	
	
	
	
	
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	
	
	
	
	
	
	
	public void bookTicketBus1Bussiness()
	{
		Admin a=new Admin();
		Scanner sc=new Scanner(System.in);
		
			a.menuBus1();
			System.out.println("PRESS 1 FOR FIRST SHIFT RESERVATION");
			System.out.println("PRESS 2 FOR SECOND SHIFT RESERVATION");
			int userChoice=0;
			userChoice=sc.nextInt();
			Ticket t=new Ticket();
			
			
			if(userChoice==1)
	     {
				System.out.println("ENTER DATE FOR RESERVATION ");
				  t.reservationDate.inputDate();
				   int count=0;
				 
					  Ticket ticket[]=getAllTickets("C:\\Users\\PC\\Desktop\\BUS 1 MORNING_B.txt");
					   count=0;
					  
					  for(int i=0;i<ticket.length;i++)
					  {
						if(t.reservationDate==ticket[i].reservationDate&&ticket[i].ticketType.
								equalsIgnoreCase("business"))
						{
							count++;
						}
					  }
				
					  av_business_m_b1=business_m_b1;
				if(bus1.av_business_m_b1>0 ||count<10)
				{
					business_m_b1--;
					p.inputPassenger();
					
					System.out.println("----------BUSSINESS CLASS TICKET----------");
					System.out.println("| TICKET ID : "+t.ticketId+"                   |");
					System.out.println("| NAME : "+p.name                          );
					System.out.println("| PHONE-NUMBER : "+p.phno          );
					System.out.println("| GENDER : "+p.gender                     );
					System.out.println("| RAWALPINDI TO LAHORE BUS SERVICE        |");
					System.out.println("| DATE :"+t.reservationDate.day+"/"+
	                                    t.reservationDate.month+"/"
							              +t.reservationDate.year);
					System.out.println("| FARE RUPEES : 800 pkr                  |");
				    System.out.println("-----------------------------------------");
				    
				    t.ticketType="business";
				    String data=t.toString()+p.toString();
					data.toString();
					FileHandler file=new FileHandler("C:\\Users\\PC\\Desktop\\BUS 1 MORNING_B.txt",true);
					file.write(data);
				}
				
           	}
			
			
			else if(userChoice==2)
		     {
				  System.out.println("ENTER DATE FOR RESERVATION ");
				  t.reservationDate.inputDate();
				   int count=0;
				 
					  Ticket ticket[]=getAllTickets("C:\\Users\\PC\\Desktop\\BUS 1 EVENING_B.txt");
					   count=0;
					  for(int i=0;i<ticket.length;i++)
					  {
						if(t.reservationDate==ticket[i].reservationDate&&ticket[i].ticketType.
								equalsIgnoreCase("business"))
						{
							count++;
						}
					  }
					
					  av_business_e_b1=business_e_b1;
					if(bus1.av_business_e_b1>0&&count<10)
					{
						business_e_b1--;
						p.inputPassenger();
						t.ticketType="business";
						System.out.println("----------BUSSINESS CLASS TICKET----------");
						System.out.println("| TICKET ID : "+t.ticketId+"                   |");
						System.out.println("| NAME : "+p.name                          );
					    System.out.println("| PHONE-NUMBER : "+p.phno          );
						System.out.println("| GENDER : "+p.gender                     );
						System.out.println("| RAWALPINDI TO LAHORE BUS SERVICE        |");
						System.out.println("| DATE :"+t.reservationDate.getDay()+"/"+
		                                    t.reservationDate.getMonth()+"/"
								              +t.reservationDate.getYear());
						System.out.println("| FARE RUPEES : 800 pkr                  |");
					    System.out.println("-----------------------------------------");
					    
					    String data=t.toString()+p.toString();
						data.toString();
						FileHandler file=new FileHandler("C:\\Users\\PC\\Desktop\\BUS 1 EVENING_B.txt",true);
						file.write(data);
					}
						           	}
	       }
	
	
	public void bookTicketBus1Economic()
	{
		Admin a=new Admin();
		Scanner sc=new Scanner(System.in);
		//ticketType="economic";
		
			a.menuBus1();
			System.out.println("PRESS 1 FOR FIRST SHIFT RESERVATION");
			System.out.println("PRESS 2 FOR SECOND SHIFT RESERVATION");
			int userChoice=0;
			userChoice=sc.nextInt();
			Ticket t=new Ticket();
			
			
			if(userChoice==1)
	     {
				System.out.println("ENTER DATE FOR RESERVATION ");
				  t.reservationDate.inputDate();
				   int count=0;
				 
					  Ticket ticket[]=getAllTickets("C:\\Users\\PC\\Desktop\\BUS 1 MORNING_E.txt");
					   count=0;
					  for(int i=0;i<ticket.length;i++)
					  {
						if(t.reservationDate==ticket[i].reservationDate&&ticket[i].ticketType.
								equalsIgnoreCase("economic"))
						{
							count++;
						}
					  }
					  
					  av_economic_m_b1=economic_m_b1;
				
				if(bus1.av_economic_m_b1>0 && count<10)
				{
					economic_m_b1--;
					p.inputPassenger();
					System.out.println("----------ECONOMIC CLASS TICKET----------");
					System.out.println("| TICKET ID : "+t.ticketId+"                   |");
					System.out.println("| NAME : "+p.name                          );
					System.out.println("| PHONE-NUMBER : "+p.phno          );
					System.out.println("| GENDER : "+p.gender                     );
					System.out.println("| RAWALPINDI TO LAHORE BUS SERVICE        |");
					System.out.println("| DATE :"+t.reservationDate.getDay()+"/"+
	                                    t.reservationDate.getMonth()+"/"
							              +t.reservationDate.getYear());
					System.out.println("| FARE RUPEES : 650 pkr                  |");
				    System.out.println("-----------------------------------------");
				    
				    t.ticketType="economic";
				    String data=t.toString()+p.toString();
					data.toString();
					FileHandler file=new FileHandler("C:\\Users\\PC\\Desktop\\BUS 1 MORNING_E.txt",true);
					file.write(data);
				}
				
           	}
			
			
			else if(userChoice==2)
		     {
				  System.out.println("ENTER DATE FOR RESERVATION ");
				  t.reservationDate.inputDate();
				   int count=0;
				 
					  Ticket ticket[]=getAllTickets("C:\\Users\\PC\\Desktop\\BUS 1 EVENING_E.txt");
					   count=0;
					  for(int i=0;i<ticket.length;i++)
					  {
						if(t.reservationDate==ticket[i].reservationDate&&ticket[i].ticketType.
								equalsIgnoreCase("economic"))
						{
							count++;
						}
					  }
					
					  av_economic_e_b1=economic_e_b1;
					if(bus1.av_economic_e_b1>0&&count<10)
					{
						economic_e_b1--;
						p.inputPassenger();
						System.out.println("----------ECONOMIC CLASS TICKET----------");
						System.out.println("| TICKET ID : "+t.ticketId+"                   |");
						System.out.println("| NAME : "+p.name                          );
					    System.out.println("| PHONE-NUMBER : "+p.phno          );
						System.out.println("| GENDER : "+p.gender                     );
						System.out.println("| RAWALPINDI TO LAHORE BUS SERVICE        |");
						System.out.println("| DATE :"+t.reservationDate.getDay()+"/"+
		                                    t.reservationDate.getMonth()+"/"
								              +t.reservationDate.getYear());
						System.out.println("| FARE RUPEES : 650 pkr                  |");
					    System.out.println("-----------------------------------------");
					    
					    t.ticketType="economic";
					    String data=t.toString()+p.toString();
						data.toString();
						FileHandler file=new FileHandler("C:\\Users\\PC\\Desktop\\BUS 1 EVENING_E.txt",true);
						file.write(data);
					}
	           	}
	       }
	
	
	public void bookTicketBus1Local()
	{
		Admin a=new Admin();
		Scanner sc=new Scanner(System.in);
		Ticket t=new Ticket();
		
			a.menuBus1();
			System.out.println("PRESS 1 FOR FIRST SHIFT RESERVATION");
			System.out.println("PRESS 2 FOR SECOND SHIFT RESERVATION");
			int userChoice=0;
			userChoice=sc.nextInt();
			
			
			if(userChoice==1)
	     {
				System.out.println("ENTER DATE FOR RESERVATION ");
				  t.reservationDate.inputDate();
				   int count=0;
				 
					  Ticket ticket[]=getAllTickets("C:\\Users\\PC\\Desktop\\BUS 1 MORNING_L.txt");
					   count=0;
					  for(int i=0;i<ticket.length;i++)
					  {
						if(t.reservationDate==ticket[i].reservationDate&&ticket[i].ticketType.
								equalsIgnoreCase("local"))
						{
							count++;
						}
					  }
				
					  
					  av_local_m_b1=local_m_b1;
				if(bus1.av_local_m_b1>0 && count<10)
				{
					local_m_b1--;
					p.inputPassenger();
			
					System.out.println("----------LOCAL TICKET----------");
					System.out.println("| TICKET ID : "+t.ticketId+"                   |");
					System.out.println("| NAME : "+p.name                          );
					System.out.println("| PHONE-NUMBER : "+p.phno          );
					System.out.println("| GENDER : "+p.gender                     );
					System.out.println("| RAWALPINDI TO LAHORE BUS SERVICE        |");
					System.out.println("| DATE :"+t.reservationDate.getDay()+"/"+
	                                    t.reservationDate.getMonth()+"/"
							              +t.reservationDate.getYear());
					System.out.println("| FARE RUPEES : 550 pkr                  |");
				    System.out.println("-----------------------------------------");
				    t.ticketType="local";
				    String data=t.toString()+p.toString();
					data.toString();
					FileHandler file=new FileHandler("C:\\Users\\PC\\Desktop\\BUS 1 MORNING_L.txt",true);
					file.write(data);
				}
				
           	}
			
			
			else if(userChoice==2)
		     {
				  System.out.println("ENTER DATE FOR RESERVATION ");
				  t.reservationDate.inputDate();
				   int count=0;
				 
					  Ticket ticket[]=getAllTickets("C:\\Users\\PC\\Desktop\\BUS 1 EVENING_L.txt");
					   count=0;
					  for(int i=0;i<ticket.length;i++)
					  {
						if(t.reservationDate==ticket[i].reservationDate&&ticket[i].ticketType.
								equalsIgnoreCase("local"))
						{
							count++;
						}
					  }
					
					  
					  av_local_e_b1=local_e_b1;
					if(bus1.av_local_e_b1>0&&count<10)
					{
						local_e_b1--;
						p.inputPassenger();
						ticketType="economic";
						System.out.println("----------LOCAL TICKET----------");
						System.out.println("| TICKET ID : "+t.ticketId+"                   |");
						System.out.println("| NAME : "+p.name                          );
					    System.out.println("| PHONE-NUMBER : "+p.phno          );
						System.out.println("| GENDER : "+p.gender                     );
						System.out.println("| RAWALPINDI TO LAHORE BUS SERVICE        |");
						System.out.println("| DATE :"+t.reservationDate.getDay()+"/"+
		                                    t.reservationDate.getMonth()+"/"
								              +t.reservationDate.getYear());
						System.out.println("| FARE RUPEES : 550 pkr                  |");
					    System.out.println("-----------------------------------------");
					    t.ticketType="local";
					    String data=t.toString()+p.toString();
						data.toString();
						FileHandler file=new FileHandler("C:\\Users\\PC\\Desktop\\BUS 1 EVENING_L.txt",true);
						file.write(data);
					}
	           	}
	       }
	
	
	
	
	
	
	///////////////////////////////////////////////////////////////////////////////////////////
	
	
	
	
	
	
	
	
	
	
	public void bookTicketBus2Bussiness()
	{
		Admin a=new Admin();
		Scanner sc=new Scanner(System.in);
				
			a.menuBus2();
			System.out.println("PRESS 1 FOR FIRST SHIFT RESERVATION");
			System.out.println("PRESS 2 FOR SECOND SHIFT RESERVATION");
			int userChoice=0;
			userChoice=sc.nextInt();
			Ticket t=new Ticket();
			
			
			if(userChoice==1)
	     {
				System.out.println("ENTER DATE FOR RESERVATION ");
				  t.reservationDate.inputDate();
				   int count=0;
				 
					  Ticket ticket[]=getAllTickets("C:\\Users\\PC\\Desktop\\BUS 2 MORNING_B.txt");
					   count=0;
					  for(int i=0;i<ticket.length;i++)
					  {
						if(t.reservationDate==ticket[i].reservationDate&&ticket[i].ticketType.
								equalsIgnoreCase("business"))
						{
							count++;
						}
					  }
				
					  av_business_m_b2=business_m_b2;
				if(bus2.av_business_m_b2>0 && count<10)
				{
					business_m_b2--;
					p.inputPassenger();
					
					System.out.println("----------BUSINESS CLASS TICKET----------");
					System.out.println("| TICKET ID : "+t.ticketId+"                   |");
					System.out.println("| NAME : "+p.name                          );
					System.out.println("| PHONE-NUMBER : "+p.phno          );
					System.out.println("| GENDER : "+p.gender                     );
					System.out.println("| RAWALPINDI TO LAHORE BUS SERVICE        |");
					System.out.println("| DATE :"+t.reservationDate.getDay()+"/"+
	                                    t.reservationDate.getMonth()+"/"
							              +t.reservationDate.getYear());
					System.out.println("| FARE RUPEES : 800 pkr                  |");
				    System.out.println("-----------------------------------------");
				    t.ticketType="business";
				    String data=t.toString()+p.toString();
					data.toString();
					FileHandler file=new FileHandler("C:\\Users\\PC\\Desktop\\BUS 2 MORNING_B.txt",true);
					file.write(data);
				}
				
           	}
			
			
			else if(userChoice==2)
		     {
				  System.out.println("ENTER DATE FOR RESERVATION ");
				  t.reservationDate.inputDate();
				   int count=0;
				 
					  Ticket ticket[]=getAllTickets("C:\\Users\\PC\\Desktop\\BUS 2 EVENING_B.txt");
					   count=0;
					  for(int i=0;i<ticket.length;i++)
					  {
						if(t.reservationDate==ticket[i].reservationDate&&ticket[i].ticketType.
								equalsIgnoreCase("business"))
						{
							count++;
						}
					  }
					
					  av_business_e_b2=business_e_b2;
					if(bus2.av_business_e_b2>0&&count<10)
					{
						business_e_b2--;
						p.inputPassenger();
						t.ticketType="bussiness";
						System.out.println("----------BUSSINESS CLASS TICKET----------");
						System.out.println("| TICKET ID : "+t.ticketId+"                   |");
						System.out.println("| NAME : "+p.name                          );
					    System.out.println("| PHONE-NUMBER : "+p.phno          );
						System.out.println("| GENDER : "+p.gender                     );
						System.out.println("| RAWALPINDI TO LAHORE BUS SERVICE        |");
						System.out.println("| DATE :"+t.reservationDate.getDay()+"/"+
		                                    t.reservationDate.getMonth()+"/"
								              +t.reservationDate.getYear());
						System.out.println("| FARE RUPEES : 800 pkr                  |");
					    System.out.println("-----------------------------------------");
					    
					    String data=t.toString()+p.toString();
						data.toString();
						FileHandler file=new FileHandler("C:\\Users\\PC\\Desktop\\BUS 2 EVENING_B.txt",true);
						file.write(data);
					}
						           	}
	       }
	
	
	public void bookTicketBus2Economic()
	{
		Admin a=new Admin();
		Scanner sc=new Scanner(System.in);
		
			a.menuBus1();
			System.out.println("PRESS 1 FOR FIRST SHIFT RESERVATION");
			System.out.println("PRESS 2 FOR SECOND SHIFT RESERVATION");
			int userChoice=0;
			userChoice=sc.nextInt();
			Ticket t=new Ticket();
			
			
			if(userChoice==1)
	     {
				System.out.println("ENTER DATE FOR RESERVATION ");
				  t.reservationDate.inputDate();
				   int count=0;
				 
					  Ticket ticket[]=getAllTickets("C:\\Users\\PC\\Desktop\\BUS 2 MORNING_E.txt");
					   count=0;
					  for(int i=0;i<ticket.length;i++)
					  {
						if(t.reservationDate==ticket[i].reservationDate&&ticket[i].ticketType.
								equalsIgnoreCase("economic"))
						{
							count++;
						}
					  }
					  
					  av_economic_m_b2=economic_m_b2;
				
				if(bus2.av_economic_m_b2>0 && count<10)
				{
					economic_m_b2--;
					p.inputPassenger();
					System.out.println("----------ECONOMIC CLASS TICKET----------");
					System.out.println("| TICKET ID : "+t.ticketId+"                   |");
					System.out.println("| NAME : "+p.name                          );
					System.out.println("| PHONE-NUMBER : "+p.phno          );
					System.out.println("| GENDER : "+p.gender                     );
					System.out.println("| RAWALPINDI TO LAHORE BUS SERVICE        |");
					System.out.println("| DATE :"+t.reservationDate.getDay()+"/"+
	                                    t.reservationDate.getMonth()+"/"
							              +t.reservationDate.getYear());
					System.out.println("| FARE RUPEES : 650 pkr                  |");
				    System.out.println("-----------------------------------------");
				    
				    t.ticketType="economic";
				    String data=t.toString()+p.toString();
					data.toString();
					FileHandler file=new FileHandler("C:\\Users\\PC\\Desktop\\BUS 2 MORNING_E.txt",true);
					file.write(data);
				}
				
           	}
			
			
			else if(userChoice==2)
		     {
				  System.out.println("ENTER DATE FOR RESERVATION ");
				  t.reservationDate.inputDate();
				   int count=0;
				 
					  Ticket ticket[]=getAllTickets("C:\\Users\\PC\\Desktop\\BUS 2 EVENING_E.txt");
					   count=0;
					  for(int i=0;i<ticket.length;i++)
					  {
						if(t.reservationDate==ticket[i].reservationDate&&ticket[i].ticketType.
								equalsIgnoreCase("economic"))
						{
							count++;
						}
					  }
					
					  av_economic_e_b2=economic_e_b2;
					if(bus2.av_economic_e_b2>0&&count<10)
					{
						economic_e_b2--;
						p.inputPassenger();
						t.ticketType="economic";
						System.out.println("----------ECONOMIC CLASS TICKET----------");
						System.out.println("| TICKET ID : "+t.ticketId+"                   |");
						System.out.println("| NAME : "+p.name                          );
					    System.out.println("| PHONE-NUMBER : "+p.phno          );
						System.out.println("| GENDER : "+p.gender                     );
						System.out.println("| RAWALPINDI TO LAHORE BUS SERVICE        |");
						System.out.println("| DATE :"+t.reservationDate.getDay()+"/"+
		                                    t.reservationDate.getMonth()+"/"
								              +t.reservationDate.getYear());
						System.out.println("| FARE RUPEES : 650 pkr                  |");
					    System.out.println("-----------------------------------------");
					    
					    String data=t.toString()+p.toString();
						data.toString();
						FileHandler file=new FileHandler("C:\\Users\\PC\\Desktop\\BUS 2 EVENING_E.txt",true);
						file.write(data);
					}
	           	}
	       }
	
	
	public void bookTicketBus2Local()
	{
		Admin a=new Admin();
		Scanner sc=new Scanner(System.in);
		
			a.menuBus2();
			System.out.println("PRESS 1 FOR FIRST SHIFT RESERVATION");
			System.out.println("PRESS 2 FOR SECOND SHIFT RESERVATION");
			int userChoice=0;
			userChoice=sc.nextInt();
			Ticket t=new Ticket();
			
			if(userChoice==1)
	     {
				System.out.println("ENTER DATE FOR RESERVATION ");
				  t.reservationDate.inputDate();
				   int count=0;
				 
					  Ticket ticket[]=getAllTickets("C:\\Users\\PC\\Desktop\\BUS 2 MORNING_L.txt");
					   count=0;
					  for(int i=0;i<ticket.length;i++)
					  {
						if(t.reservationDate==ticket[i].reservationDate&&ticket[i].ticketType.
								equalsIgnoreCase("local"))
						{
							count++;
						}
					  }
				
					  
					  av_local_m_b2=local_m_b2;
				if(bus2.av_local_m_b2>0 && count<10)
				{
					local_m_b2--;
					p.inputPassenger();
					System.out.println("----------LOCAL TICKET----------");
					System.out.println("| TICKET ID : "+t.ticketId+"                   |");
					System.out.println("| NAME : "+p.name                          );
					System.out.println("| PHONE-NUMBER : "+p.phno          );
					System.out.println("| GENDER : "+p.gender                     );
					System.out.println("| RAWALPINDI TO LAHORE BUS SERVICE        |");
					System.out.println("| DATE :"+t.reservationDate.getDay()+"/"+
	                                    t.reservationDate.getMonth()+"/"
							              +t.reservationDate.getYear());
					System.out.println("| FARE RUPEES : 550 pkr                  |");
				    System.out.println("-----------------------------------------");
				    
				    t.ticketType="local";
				    String data=t.toString()+p.toString();
					data.toString();
					FileHandler file=new FileHandler("C:\\Users\\PC\\Desktop\\BUS 2 MORNING_L.txt",true);
					file.write(data);
				}
				
           	}
			
			
			else if(userChoice==2)
		     {
				  System.out.println("ENTER DATE FOR RESERVATION ");
				  t.reservationDate.inputDate();
				   int count=0;
				 
					  Ticket ticket[]=getAllTickets("C:\\Users\\PC\\Desktop\\BUS 2 EVENING_L.txt");
					   count=0;
					  for(int i=0;i<ticket.length;i++)
					  {
						if(t.reservationDate==ticket[i].reservationDate&&ticket[i].ticketType.
								equalsIgnoreCase("local"))
						{
							count++;
						}
					  }
					
					  
					  av_local_e_b2=local_e_b2;
					if(bus2.av_local_e_b2>0&&count<10)
					{
						local_e_b2--;
						p.inputPassenger();
	
						t.ticketType="economic";
						System.out.println("----------LOCAL TICKET----------");
						System.out.println("| TICKET ID : "+t.ticketId+"                   |");
						System.out.println("| NAME : "+p.name                          );
					    System.out.println("| PHONE-NUMBER : "+p.phno          );
						System.out.println("| GENDER : "+p.gender                     );
						System.out.println("| RAWALPINDI TO LAHORE BUS SERVICE        |");
						System.out.println("| DATE :"+t.reservationDate.getDay()+"/"+
		                                    t.reservationDate.getMonth()+"/"
								              +t.reservationDate.getYear());
						System.out.println("| FARE RUPEES : 550 pkr                  |");
					    System.out.println("-----------------------------------------");
					    
					    String data=t.toString()+p.toString();
						data.toString();
						FileHandler file=new FileHandler("C:\\Users\\PC\\Desktop\\BUS 2 EVENING_L.txt",true);
						file.write(data);
					}
	           	}
	       }
	
	
	
	
	
//////////////////////////////////////////////////////////////////////////////////////////////////
	
	
	
	
	
	
	
	public void bookTicketBus3Bussiness()
	{
		Admin a=new Admin();
		Scanner sc=new Scanner(System.in);
		
			a.menuBus3();
			System.out.println("PRESS 1 FOR FIRST SHIFT RESERVATION");
			System.out.println("PRESS 2 FOR SECOND SHIFT RESERVATION");
			int userChoice=0;
			userChoice=sc.nextInt();
			Ticket t=new Ticket();
			
			
			if(userChoice==1)
	     {
				System.out.println("ENTER DATE FOR RESERVATION ");
				  t.reservationDate.inputDate();
				   int count=0;
				 
					  Ticket ticket[]=getAllTickets("C:\\Users\\PC\\Desktop\\BUS 3 MORNING_B.txt");
					   count=0;
					  for(int i=0;i<ticket.length;i++)
					  {
						if(t.reservationDate==ticket[i].reservationDate&&ticket[i].ticketType.
								equalsIgnoreCase("business"))
						{
							count++;
						}
					  }
				
					  av_business_m_b3=business_m_b3;
				if(bus3.av_business_m_b3>0 && count<10)
				{
					business_m_b3--;
					p.inputPassenger();
					System.out.println("----------BUSSINESS CLASS TICKET----------");
					System.out.println("| TICKET ID : "+t.ticketId+"                   |");
					System.out.println("| NAME : "+p.name                          );
					System.out.println("| PHONE-NUMBER : "+p.phno          );
					System.out.println("| GENDER : "+p.gender                     );
					System.out.println("| RAWALPINDI TO LAHORE BUS SERVICE        |");
					System.out.println("| DATE :"+t.reservationDate.getDay()+"/"+
	                                    t.reservationDate.getMonth()+"/"
							              +t.reservationDate.getYear());
					System.out.println("| FARE RUPEES : 800 pkr                  |");
				    System.out.println("-----------------------------------------");
				    t.ticketType="business";
				    String data=t.toString()+p.toString();
					data.toString();
					FileHandler file=new FileHandler("C:\\Users\\PC\\Desktop\\BUS 3 MORNING_B.txt",true);
					file.write(data);
				}
				
           	}
			
			
			else if(userChoice==2)
		     {
				  System.out.println("ENTER DATE FOR RESERVATION ");
				  t.reservationDate.inputDate();
				   int count=0;
				 
					  Ticket ticket[]=getAllTickets("C:\\Users\\PC\\Desktop\\BUS 3 EVENING_B.txt");
					   count=0;
					  for(int i=0;i<ticket.length;i++)
					  {
						if(t.reservationDate==ticket[i].reservationDate&&ticket[i].ticketType.
								equalsIgnoreCase("business"))
						{
							count++;
						}
					  }
					
					  av_business_e_b3=business_e_b3;
					if(bus3.av_business_e_b3>0&&count<10)
					{
						business_e_b3--;
						p.inputPassenger();
						t.ticketType="bussiness";
						System.out.println("----------BUSSINESS CLASS TICKET----------");
						System.out.println("| TICKET ID : "+t.ticketId+"                   |");
						System.out.println("| NAME : "+p.name                          );
					    System.out.println("| PHONE-NUMBER : "+p.phno          );
						System.out.println("| GENDER : "+p.gender                     );
						System.out.println("| RAWALPINDI TO LAHORE BUS SERVICE        |");
						System.out.println("| DATE :"+t.reservationDate.getDay()+"/"+
		                                    t.reservationDate.getMonth()+"/"
								              +t.reservationDate.getYear());
						System.out.println("| FARE RUPEES : 800 pkr                  |");
					    System.out.println("-----------------------------------------");
					    
					    String data=t.toString()+p.toString();
						data.toString();
						FileHandler file=new FileHandler("C:\\Users\\PC\\Desktop\\BUS 3 EVENING_B.txt",true);
						file.write(data);
					}
						           	}
	       }
	
	
	public void bookTicketBus3Economic()
	{
		Admin a=new Admin();
		Scanner sc=new Scanner(System.in);
		
			a.menuBus3();
			System.out.println("PRESS 1 FOR FIRST SHIFT RESERVATION");
			System.out.println("PRESS 2 FOR SECOND SHIFT RESERVATION");
			int userChoice=0;
			userChoice=sc.nextInt();
			Ticket t=new Ticket();
			
			
			if(userChoice==1)
	     {
				System.out.println("ENTER DATE FOR RESERVATION ");
				  t.reservationDate.inputDate();
				   int count=0;
				 
					  Ticket ticket[]=getAllTickets("C:\\Users\\PC\\Desktop\\BUS 3 MORNING_E.txt");
					   count=0;
					  for(int i=0;i<ticket.length;i++)
					  {
						if(t.reservationDate==ticket[i].reservationDate&&ticket[i].ticketType.
								equalsIgnoreCase("economic"))
						{
							count++;
						}
					  }
					  
					  av_economic_m_b3=economic_m_b3;
				
				if(bus3.av_economic_m_b3>0 && count<10)
				{
					economic_m_b3--;
					p.inputPassenger();
					System.out.println("----------ECONOMIC CLASS TICKET----------");
					System.out.println("| TICKET ID : "+t.ticketId+"                   |");
					System.out.println("| NAME : "+p.name                          );
					System.out.println("| PHONE-NUMBER : "+p.phno          );
					System.out.println("| GENDER : "+p.gender                     );
					System.out.println("| RAWALPINDI TO LAHORE BUS SERVICE        |");
					System.out.println("| DATE :"+t.reservationDate.getDay()+"/"+
	                                    t.reservationDate.getMonth()+"/"
							              +t.reservationDate.getYear());
					System.out.println("| FARE RUPEES : 650 pkr                  |");
				    System.out.println("-----------------------------------------");
				    
				    t.ticketType="economic";
				    String data=t.toString()+p.toString();
					data.toString();
					FileHandler file=new FileHandler("C:\\Users\\PC\\Desktop\\BUS 3 MORNING_E.txt",true);
					file.write(data);
				}
				
           	}
			
			
			else if(userChoice==2)
		     {
				  System.out.println("ENTER DATE FOR RESERVATION ");
				  t.reservationDate.inputDate();
				   int count=0;
				 
					  Ticket ticket[]=getAllTickets("C:\\Users\\PC\\Desktop\\BUS 3 EVENING_E.txt");
					   count=0;
					  for(int i=0;i<ticket.length;i++)
					  {
						if(t.reservationDate==ticket[i].reservationDate&&ticket[i].ticketType.
								equalsIgnoreCase("economic"))
						{
							count++;
						}
					  }
					
					  av_economic_e_b3=economic_e_b3;
					if(bus3.av_economic_e_b3>0&&count<10)
					{
						economic_e_b3--;
						p.inputPassenger();
						t.ticketType="economic";
						System.out.println("----------ECONOMIC CLASS TICKET----------");
						System.out.println("| TICKET ID : "+t.ticketId+"                   |");
						System.out.println("| NAME : "+p.name                          );
					    System.out.println("| PHONE-NUMBER : "+p.phno          );
						System.out.println("| GENDER : "+p.gender                     );
						System.out.println("| RAWALPINDI TO LAHORE BUS SERVICE        |");
						System.out.println("| DATE :"+t.reservationDate.getDay()+"/"+
		                                    t.reservationDate.getMonth()+"/"
								              +t.reservationDate.getYear());
						System.out.println("| FARE RUPEES : 650 pkr                  |");
					    System.out.println("-----------------------------------------");
					    
					    String data=t.toString()+p.toString();
						data.toString();
						FileHandler file=new FileHandler("C:\\Users\\PC\\Desktop\\BUS 3 EVENING_E.txt",true);
						file.write(data);
					}
	           	}
	       }
	
	
	public void bookTicketBus3Local()
	{
		Admin a=new Admin();
		Scanner sc=new Scanner(System.in);
		
			a.menuBus3();
			System.out.println("PRESS 1 FOR FIRST SHIFT RESERVATION");
			System.out.println("PRESS 2 FOR SECOND SHIFT RESERVATION");
			int userChoice=0;
			userChoice=sc.nextInt();
			Ticket t=new Ticket();
			
			
			if(userChoice==1)
	     {
				System.out.println("ENTER DATE FOR RESERVATION ");
				  t.reservationDate.inputDate();
				   int count=0;
				 
					  Ticket ticket[]=getAllTickets("C:\\Users\\PC\\Desktop\\BUS 3 MORNING_L.txt");
					   count=0;
					  for(int i=0;i<ticket.length;i++)
					  {
						if(t.reservationDate==ticket[i].reservationDate&&ticket[i].ticketType.
								equalsIgnoreCase("local"))
						{
							count++;
						}
					  }
				
					  
					  av_local_m_b3=local_m_b3;
				if(bus3.av_local_m_b3>0 && count<10)
				{
					local_m_b3--;
					p.inputPassenger();
					System.out.println("----------LOCAL TICKET----------");
					System.out.println("| TICKET ID : "+t.ticketId+"                   |");
					System.out.println("| NAME : "+p.name                          );
					System.out.println("| PHONE-NUMBER : "+p.phno          );
					System.out.println("| GENDER : "+p.gender                     );
					System.out.println("| RAWALPINDI TO LAHORE BUS SERVICE        |");
					System.out.println("| DATE :"+t.reservationDate.getDay()+"/"+
	                                    t.reservationDate.getMonth()+"/"
							              +t.reservationDate.getYear());
					System.out.println("| FARE RUPEES : 550 pkr                  |");
				    System.out.println("-----------------------------------------");
				    t.ticketType="local";
				    String data=t.toString()+p.toString();
					data.toString();
					FileHandler file=new FileHandler("C:\\Users\\PC\\Desktop\\BUS 3 MORNING_L.txt",true);
					file.write(data);
				}
				
           	}
			
			
			else if(userChoice==2)
		     {
				  System.out.println("ENTER DATE FOR RESERVATION ");
				  t.reservationDate.inputDate();
				   int count=0;
				 
					  Ticket ticket[]=getAllTickets("C:\\Users\\PC\\Desktop\\BUS 3 EVENING_L.txt");
					   count=0;
					  for(int i=0;i<ticket.length;i++)
					  {
						if(t.reservationDate==ticket[i].reservationDate&&ticket[i].ticketType.
								equalsIgnoreCase("local"))
						{
							count++;
						}
					  }
					
					  
					  av_local_e_b3=local_e_b3;
					if(bus3.av_local_e_b3>0&&count<10)
					{
						local_e_b3--;
						p.inputPassenger();
						t.ticketType="local";
						System.out.println("----------LOCAL TICKET----------");
						System.out.println("| TICKET ID : "+t.ticketId+"                   |");
						System.out.println("| NAME : "+p.name                          );
					    System.out.println("| PHONE-NUMBER : "+p.phno          );
						System.out.println("| GENDER : "+p.gender                     );
						System.out.println("| RAWALPINDI TO LAHORE BUS SERVICE        |");
						System.out.println("| DATE :"+t.reservationDate.getDay()+"/"+
		                                    t.reservationDate.getMonth()+"/"
								              +t.reservationDate.getYear());
						System.out.println("| FARE RUPEES : 550 pkr                  |");
					    System.out.println("-----------------------------------------");
					    
					    String data=t.toString()+p.toString();
						data.toString();
						FileHandler file=new FileHandler("C:\\Users\\PC\\Desktop\\BUS 3 EVENING_L.txt",true);
						file.write(data);
					}
	           	}
	       }
	
	
	
	
	
	
	
//////////////////////////////////////////////////////////////////////////////////////////////////







public void bookTicketBus4Bussiness()
{
Admin a=new Admin();

Scanner sc=new Scanner(System.in);

a.menuBus4();
System.out.println("PRESS 1 FOR FIRST SHIFT RESERVATION");
System.out.println("PRESS 2 FOR SECOND SHIFT RESERVATION");
int userChoice=0;
userChoice=sc.nextInt();
Ticket t=new Ticket();


if(userChoice==1)
{
System.out.println("ENTER DATE FOR RESERVATION ");
t.reservationDate.inputDate();
int count=0;

Ticket ticket[]=getAllTickets("C:\\Users\\PC\\Desktop\\BUS 4 MORNING_B.txt");
count=0;
for(int i=0;i<ticket.length;i++)
{
if(t.reservationDate==ticket[i].reservationDate&&ticket[i].ticketType.
equalsIgnoreCase("business"))
{
count++;
}
}

av_business_m_b4=business_m_b4;
if(bus4.av_business_m_b4>0 && count<10)
{
business_m_b4--;
p.inputPassenger();
System.out.println("----------BUSSINESS CLASS TICKET----------");
System.out.println("| TICKET ID : "+t.ticketId+"                   |");
System.out.println("| NAME : "+p.name                          );
System.out.println("| PHONE-NUMBER : "+p.phno          );
System.out.println("| GENDER : "+p.gender                     );
System.out.println("| RAWALPINDI TO LAHORE BUS SERVICE        |");
System.out.println("| DATE :"+t.reservationDate.getDay()+"/"+
t.reservationDate.getMonth()+"/"
+t.reservationDate.getYear());
System.out.println("| FARE RUPEES : 800 pkr                  |");
System.out.println("-----------------------------------------");
t.ticketType="business";
String data=t.toString()+p.toString();
data.toString();
FileHandler file=new FileHandler("C:\\Users\\PC\\Desktop\\BUS 4 MORNING_B.txt",true);
file.write(data);
}

}


else if(userChoice==2)
{
System.out.println("ENTER DATE FOR RESERVATION ");
t.reservationDate.inputDate();
int count=0;

Ticket ticket[]=getAllTickets("C:\\Users\\PC\\Desktop\\BUS 4 EVENING_B.txt");
count=0;
for(int i=0;i<ticket.length;i++)
{
if(date==ticket[i].reservationDate&&ticket[i].ticketType.
equalsIgnoreCase("business"))
{
count++;
}
}

av_business_e_b4=business_e_b4;
if(bus4.av_business_e_b4>0&&count<10)
{
business_e_b4--;
p.inputPassenger();
t.ticketType="bussiness";
System.out.println("----------BUSINESS CLASS TICKET----------");
System.out.println("| TICKET ID : "+t.ticketId+"                   |");
System.out.println("| NAME : "+p.name                          );
System.out.println("| PHONE-NUMBER : "+p.phno          );
System.out.println("| GENDER : "+p.gender                     );
System.out.println("| RAWALPINDI TO LAHORE BUS SERVICE        |");
System.out.println("| DATE :"+t.reservationDate.getDay()+"/"+
t.reservationDate.getMonth()+"/"
+t.reservationDate.getYear());
System.out.println("| FARE RUPEES : 800 pkr                  |");
System.out.println("-----------------------------------------");

String data=t.toString()+p.toString();
data.toString();
FileHandler file=new FileHandler("C:\\Users\\PC\\Desktop\\BUS 4 EVENING_B.txt",true);
file.write(data);
}
}
}


public void bookTicketBus4Economic()
{
Admin a=new Admin();
Scanner sc=new Scanner(System.in);
a.menuBus4();
System.out.println("PRESS 1 FOR FIRST SHIFT RESERVATION");
System.out.println("PRESS 2 FOR SECOND SHIFT RESERVATION");
int userChoice=0;
userChoice=sc.nextInt();
Ticket t=new Ticket();


if(userChoice==1)
{
System.out.println("ENTER DATE FOR RESERVATION ");
t.reservationDate.inputDate();
int count=0;

Ticket ticket[]=getAllTickets("C:\\Users\\PC\\Desktop\\BUS 4 MORNING_E.txt");
count=0;
for(int i=0;i<ticket.length;i++)
{
if(t.reservationDate==ticket[i].reservationDate&&ticket[i].ticketType.
equalsIgnoreCase("economic"))
{
count++;
}
}

av_economic_m_b4=economic_m_b4;

if(bus4.av_economic_m_b4>0 && count<10)
{
economic_m_b4--;
p.inputPassenger();

System.out.println("----------ECONOMIC CLASS TICKET----------");
System.out.println("| TICKET ID : "+t.ticketId+"                   |");
System.out.println("| NAME : "+p.name                          );
System.out.println("| PHONE-NUMBER : "+p.phno          );
System.out.println("| GENDER : "+p.gender                     );
System.out.println("| RAWALPINDI TO LAHORE BUS SERVICE        |");
System.out.println("| DATE :"+reservationDate.getDay()+"/"+
reservationDate.getMonth()+"/"
+reservationDate.getYear());
System.out.println("| FARE RUPEES : 650 pkr                  |");
System.out.println("-----------------------------------------");

t.ticketType="economic";
String data=t.toString()+p.toString();
data.toString();
FileHandler file=new FileHandler("C:\\Users\\PC\\Desktop\\BUS 4 MORNING_E.txt",true);
file.write(data);
}

}


else if(userChoice==2)
{
System.out.println("ENTER DATE FOR RESERVATION ");
t.reservationDate.inputDate();
int count=0;

Ticket ticket[]=getAllTickets("C:\\Users\\PC\\Desktop\\BUS 4 EVENING_E.txt");
count=0;
for(int i=0;i<ticket.length;i++)
{
if(t.reservationDate==ticket[i].reservationDate&&ticket[i].ticketType.
equalsIgnoreCase("economic"))
{
count++;
}
}

av_economic_e_b4=economic_e_b4;
if(bus4.av_economic_e_b4>0&&count<10)
{
economic_e_b4--;
p.inputPassenger();
t.ticketType="economic";
System.out.println("----------ECONOMIC CLASS TICKET----------");
System.out.println("| TICKET ID : "+t.ticketId+"                   |");
System.out.println("| NAME : "+p.name                          );
System.out.println("| PHONE-NUMBER : "+p.phno          );
System.out.println("| GENDER : "+p.gender                     );
System.out.println("| RAWALPINDI TO LAHORE BUS SERVICE        |");
System.out.println("| DATE :"+t.reservationDate.getDay()+"/"+
t.reservationDate.getMonth()+"/"
+t.reservationDate.getYear());
System.out.println("| FARE RUPEES : 650 pkr                  |");
System.out.println("-----------------------------------------");

String data=t.toString()+p.toString();
data.toString();
FileHandler file=new FileHandler("C:\\Users\\PC\\Desktop\\BUS 4 EVENING_E.txt",true);
file.write(data);
}
}
}


public void bookTicketBus4Local()
{
Admin a=new Admin();
Scanner sc=new Scanner(System.in);

a.menuBus4();
System.out.println("PRESS 1 FOR FIRST SHIFT RESERVATION");
System.out.println("PRESS 2 FOR SECOND SHIFT RESERVATION");
int userChoice=0;
userChoice=sc.nextInt();
Ticket t=new Ticket();


if(userChoice==1)
{
System.out.println("ENTER DATE FOR RESERVATION ");
t.reservationDate.inputDate();
int count=0;

Ticket ticket[]=getAllTickets("C:\\Users\\PC\\Desktop\\BUS 4 MORNING_L.txt");
count=0;
for(int i=0;i<ticket.length;i++)
{
if(t.reservationDate==ticket[i].reservationDate&&ticket[i].ticketType.
equalsIgnoreCase("local"))
{
count++;
}
}


av_local_m_b4=local_m_b4;
if(bus4.av_local_m_b4>0 && count<10)
{
local_m_b4--;
p.inputPassenger();
System.out.println("----------LOCAL TICKET----------");
System.out.println("| TICKET ID : "+t.ticketId+"                   |");
System.out.println("| NAME : "+p.name                          );
System.out.println("| PHONE-NUMBER : "+p.phno          );
System.out.println("| GENDER : "+p.gender                     );
System.out.println("| RAWALPINDI TO LAHORE BUS SERVICE        |");
System.out.println("| DATE :"+t.reservationDate.getDay()+"/"+
t.reservationDate.getMonth()+"/"
+t.reservationDate.getYear());
System.out.println("| FARE RUPEES : 550 pkr                  |");
System.out.println("-----------------------------------------");

t.ticketType="local";
String data=t.toString()+p.toString();
data.toString();
FileHandler file=new FileHandler("C:\\Users\\PC\\Desktop\\BUS 4 MORNING_L.txt",true);
file.write(data);
}

}


else if(userChoice==2)
{
System.out.println("ENTER DATE FOR RESERVATION ");
t.reservationDate.inputDate();
int count=0;

Ticket ticket[]=getAllTickets("C:\\Users\\PC\\Desktop\\BUS 4 EVENING_L.txt");
count=0;
for(int i=0;i<ticket.length;i++)
{
if(t.reservationDate==ticket[i].reservationDate&&ticket[i].ticketType.
equalsIgnoreCase("local"))
{
count++;
}
}


av_local_e_b4=local_e_b4;
if(bus4.av_local_e_b4>0&&count<10)
{
local_e_b4--;
p.inputPassenger();
t.ticketType="economic";
System.out.println("----------LOCAL TICKET----------");
System.out.println("| TICKET ID : "+t.ticketId+"                   |");
System.out.println("| NAME : "+p.name                          );
System.out.println("| PHONE-NUMBER : "+p.phno          );
System.out.println("| GENDER : "+p.gender                     );
System.out.println("| RAWALPINDI TO LAHORE BUS SERVICE        |");
System.out.println("| DATE :"+t.reservationDate.getDay()+"/"+
t.reservationDate.getMonth()+"/"
+t.reservationDate.getYear());
System.out.println("| FARE RUPEES : 550 pkr                  |");
System.out.println("-----------------------------------------");

String data=t.toString()+p.toString();
data.toString();
FileHandler file=new FileHandler("C:\\Users\\PC\\Desktop\\BUS 4 EVENING_L.txt",true);
file.write(data);
}
}
}


	
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////







		
	
}
