package finall;

import java.util.Scanner;

public class Driver {
private int id;
private String name;
private String CNIC;
Address address=new Address("rg","wry","rhtw","wryet");
private boolean license;
private static int auto_id;
public Driver(int i,String n,String c,Address a,boolean l)
{
	id=i;name=n;CNIC=c;address=a;license=l;
}
public String toString()
{
	String data=id+"#"+name+"#"+CNIC+"#"+address.toString()+"\n";
	return data;
}
static
{
	FileHandler file=new FileHandler("C:\\Users\\PC\\Desktop\\Driver.txt",false);
	String d_data=file.read();
	if(d_data.equals(""))
	{
		auto_id=100;
	}
	else
	{
		String rows[]=d_data.split("\n");
		String row=rows[rows.length-1];
		String []att=row.split("#");
	     auto_id=Integer.parseInt(att[0]+1);
	}
}
public boolean isValidCNIC(String cnic) {
    if (cnic.length() != 15) {
        return false;
    }
    if (cnic.charAt(5) != '-' || cnic.charAt(13) != '-') {
        return false;
    }
    for (int i = 0; i < cnic.length(); i++) {
        if (i != 5 && i != 13 && !Character.isDigit(cnic.charAt(i))) {
            return false;
        }
    }

    return true;
}
public void addDriver()
{
	Scanner sc=new Scanner(System.in);
	id=auto_id;
System.out.println("Driver Id : "+id+"\n");
System.out.println("Enter Driver Name : ");
name=sc.next();
System.out.println("Enter Driver CNIC : ");
CNIC=sc.next();
if(isValidCNIC(CNIC))
{
	System.out.println("CNIC is valid ");
}
else if (isValidCNIC(CNIC)==false) 
{
	System.out.println("Invalid Driver CNIC, Re-enter : ");
	CNIC=sc.next();
}
address.inputAddress();
System.out.println("Press 1 if you hold license \nPress 2 if you don't hold license");
int choice=0;
choice=sc.nextInt();
if(choice==1)
{
	license=true;
	new Driver(id,name,CNIC,address, license);
	String data=id+"#"+name+"#"+CNIC+"#"+address.toString()+"\n";
	data.toString();
	FileHandler file=new FileHandler("C:\\Users\\PC\\Desktop\\Driver.txt",true);
	file.write(data);
}
else
{
	System.out.println("Sorry, Unable to Add this Driver ");
}
}
}