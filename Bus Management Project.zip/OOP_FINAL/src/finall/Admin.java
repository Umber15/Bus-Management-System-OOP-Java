package finall;

import java.util.Scanner;


public class Admin extends Route{
Buss bus1=new Buss();
Buss bus2=new Buss();
Buss bus3=new Buss();
Buss bus4=new Buss();


public void menuBus1()
{
	System.out.println("--------------BUS TIMINGS--------------");
	System.out.println("FIRST SHIFT : ");
	System.out.println("RAWALPINDI TO LAHORE BUS SERVICE ");
	System.out.println("Departure Time from Rawalpindi :" +"5:00 am ");
	System.out.println("Arrival Time At Lahore : "+"10:00 am\n");
	System.out.println("------MINI TERMINALS ------");
	System.out.println(" Jhelem At :"+"7:30 am");
	System.out.println(" Gujrat At:"+"8:45 am");
	System.out.println(" GujranWala At :"+"9:20 am\n");
	
	System.out.println("SECOND SHIFT : ");
	System.out.println("LAHORE TO RAWALPINDI BUS SERVICE ");
	System.out.println("Departure Time from LAHORE :" +"12:00 pm ");
	System.out.println("Arrival Time At Lahore : "+"5:00 pm\n");
	System.out.println("------MINI TERMINALS ------");
	System.out.println(" GujranWala At :"+"2:30 pm");
	System.out.println(" Gujrat At :"+"3:45 pm");
	System.out.println(" Jhelem At :"+"4:20 pm");
}


public void menuBus2()
{
	System.out.println("--------------BUS TIMINGS--------------");
	System.out.println("FIRST SHIFT : ");
	System.out.println("RAWALPINDI TO PESHAWAR BUS SERVICE ");
	System.out.println("Departure Time from Rawalpindi :" +"5:00 am ");
	System.out.println("Arrival Time At PESHAWAR : "+"10:00 am\n");
	System.out.println("------MINI TERMINALS ------");
	System.out.println(" Texila At :"+"7:30 am");
	System.out.println(" Attock At :"+"8:45 am");
	System.out.println(" Nowshera At :"+"9:20 am\n");
	
	System.out.println("SECOND SHIFT : ");
	System.out.println("PESHAWAR TO RAWALPINDI BUS SERVICE ");
	System.out.println("Departure Time from PESHAWAR :" +"12:00 pm ");
	System.out.println("Arrival Time At RAWALPINDI : "+"5:00 pm\n");
	System.out.println("------MINI TERMINALS ------");
	System.out.println("Nowshera at  :"+"2:30 pm");
	System.out.println("Attock At :"+"3:45 pm");
	System.out.println("Texila At :"+"4:20 pm");
}


public void menuBus3()
{
	System.out.println("--------------BUS TIMINGS--------------");
	System.out.println("FIRST SHIFT : ");
	System.out.println("KARACHI TO PESHAWAR BUS SERVICE ");
	System.out.println("Departure Time from Karachi :" +"5:00 am ");
	System.out.println("Arrival Time At Peshawar : "+"10:00 am\n");
	System.out.println("------MINI TERMINALS ------");
	System.out.println(" Hyderabad at :"+"7:30 am");
	System.out.println(" Rahim Yar Khan at :"+"8:45 am");
	System.out.println(" Dera Ghazi Khan :"+"9:20 am\n");
	
	System.out.println("SECOND SHIFT : ");
	System.out.println("LAHORE TO RAWALPINDI BUS SERVICE ");
	System.out.println("Departure Time from LAHORE :" +"12:00 pm ");
	System.out.println("Arrival Time At Lahore : "+"5:00 pm\n");
	System.out.println("------MINI TERMINALS ------");
	System.out.println(" Dera Ghazi Khan At :"+"2:30 pm");
	System.out.println(" Rahim Yar Khan At  :"+"3:45 pm");
	System.out.println(" HyderAbad At :"+"4:20 pm");
}

public void menuBus4()
{
	
	System.out.println("--------------BUS TIMINGS--------------");
	System.out.println("FIRST SHIFT : ");
	System.out.println("PESHAWAR TO LAHORE BUS SERVICE ");
	System.out.println("Departure Time from PESHAWAR :" +"5:00 am ");
	System.out.println("Arrival Time At Lahore : "+"10:00 am\n");
	System.out.println("------MINI TERMINALS ------");
	System.out.println(" KAMIKE AT :"+"7:30 am");
	System.out.println(" GUJRANWALA At:"+"8:45 am");
	System.out.println(" MARDAN At :"+"9:20 am\n");
	
	System.out.println("SECOND SHIFT : ");
	System.out.println("LAHORE TO PESHAWAR BUS SERVICE ");
	System.out.println("Departure Time from LAHORE :" +"12:00 pm ");
	System.out.println("Arrival Time At PESHAWAR  : "+"5:00 pm\n");
	System.out.println("------MINI TERMINALS ------");
	System.out.println(" MARDAN At :"+"2:30 pm");
	System.out.println(" GUJRANWALA At :"+"3:45 pm");
	System.out.println(" KAMOKE At :"+"4:20 pm");
}

public void chooseClass()
{
	System.out.println("1. TO RESERVE SEAT IN BUSINESS CLASS");
	System.out.println("2. TO RESERVE SEAT IN ECONOMIC CLASS");
	System.out.println("3. TO RESERVE SEAT IN LOCAL CLASS");
}

public void menu0()
{
	System.out.println("--------BUS MANAGEMENT SYSTEM--------");
	System.out.println("1. TO BOOK TICKET ");
	System.out.println("2. TO CANCEL TICKET");
	System.out.println("3. TO EXIT ");
}

public void deleteMenu()
{
	System.out.println("1. TO DELETE TICKET FOR BUS 1");
	System.out.println("2. TO DELETE TICKET FOR BUS 2");
	System.out.println("3. TO DELETE TICKET FOR BUS 3");
	System.out.println("4. TO DELETE TICKET FOR BUS 4");	
}
public void chooseTime()
{
	System.out.println("1. TO DELETE MORNING TICKET");
	System.out.println("2. TO DELETE EVENING TICKET");	
}
public void deleteClass()
{
	System.out.println("1. TO DELETE BUSINESS TICKET");
	System.out.println("2. TO DELETE ECONOMIC TICKET");
	System.out.println("3. TO DELETE LOCAL TICKET");
}
public void menu()
{
	
	System.out.println("ROUTE OF BUS-1 "+t1.getTerminal_A()+" to "+t1.getTerminal_B()+" and vice versa");
	System.out.println("ROUTE OF BUS-2 "+t1.getTerminal_A()+" to "+t1.getTerminal_D()+" and vice versa");
	System.out.println("ROUTE OF BUS-3 "+t1.getTerminal_C()+" to "+t1.getTerminal_D()+" and vice versa");
	System.out.println("ROUTE OF BUS-4 "+t1.getTerminal_D()+" to "+t1.getTerminal_B()+" and vice versa");
	System.out.println("\nPRESS 1 TO BOOK TICKET IN BUS-1");
	System.out.println("PRESS 2 TO BOOK TICKET IN BUS-2");
	System.out.println("PRESS 3 TO BOOK TICKET IN BUS-3");
	System.out.println("PRESS 4 TO BOOK TICKET IN BUS-4");

} 

public Buss[] getAllBuses()
{
	FileHandler file=new FileHandler("C:\\Users\\PC\\Desktop\\BUS 1 MORNING.txt",false);
	String filedata=file.read();
	if(filedata.equals(""))
	{
		return null;
	}
	String rows[]=filedata.split("\n");
	Buss []bdata=new Buss[rows.length];
	for(int i=0;i<rows.length;i++)
	{
		bdata[i]=new Buss(rows[i]);
	}
	return bdata;
}
public int ticketId;
public static int auto_ticket;
Date date=new Date(1,1,1);
static {
	FileHandler file=new FileHandler("path",false);
	String bus_data=file.read();
	if(bus_data.equals(""))
	{
		auto_ticket=10;
	}
	else
	{
		String rows[]=bus_data.split("\n");
		String row=rows[rows.length-1];
		String []att=row.split("#");
	     int ff=Integer.parseInt(att[0]);
	     ff=ff+1;
	      auto_ticket=ff;
	}	
}
public String toString()
{
	return ticketId+"#"+date.getDay()+"/"+date.getMonth()+"/"+date.getYear();
}



}