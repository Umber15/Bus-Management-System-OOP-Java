package finall;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
public class Buss {

	    private int business_seats = 10;
	    private int economic_seats = 10;
	    private int local_seats = 10;

	    // bus 1 
	    public static int business_m_b1; 
	    public static int economic_m_b1;
	    public static int local_m_b1;
	    public int av_business_m_b1;
	    public int av_economic_m_b1;
	    public int av_local_m_b1;
	    public static int business_e_b1; 
	    public static int economic_e_b1;
	    public static int local_e_b1;
	    public int av_business_e_b1;
	    public int av_economic_e_b1;
	    public int av_local_e_b1;

	    // bus 2 
	    public static int business_m_b2; 
	    public static int economic_m_b2;
	    public static int local_m_b2;
	    public int av_business_m_b2;
	    public int av_economic_m_b2;
	    public int av_local_m_b2;
	    public static int business_e_b2; 
	    public static int economic_e_b2;
	    public static int local_e_b2;
	    public int av_business_e_b2;
	    public int av_economic_e_b2;
	    public int av_local_e_b2;

	    // bus 3 
	    public static int business_m_b3; 
	    public static int economic_m_b3;
	    public static int local_m_b3;
	    public int av_business_m_b3;
	    public int av_economic_m_b3;
	    public int av_local_m_b3;
	    public static int business_e_b3; 
	    public static int economic_e_b3;
	    public static int local_e_b3;
	    public int av_business_e_b3;
	    public int av_economic_e_b3;
	    public int av_local_e_b3;

	    // bus 4
	    public static int business_m_b4; 
	    public static int economic_m_b4;
	    public static int local_m_b4;
	    public int av_business_m_b4;
	    public int av_economic_m_b4;
	    public int av_local_m_b4;
	    public static int business_e_b4; 
	    public static int economic_e_b4;
	    public static int local_e_b4;
	    public int av_business_e_b4;
	    public int av_economic_e_b4;
	    public int av_local_e_b4;

	    public Buss() {
	        av_business_m_b1 = business_m_b1;
	        av_economic_m_b1 = economic_m_b1;
	        av_local_m_b1 = local_m_b1;
	        av_business_e_b1 = business_e_b1;
	        av_economic_e_b1 = economic_e_b1;
	        av_local_e_b1 = local_e_b1;

	        av_business_m_b2 = business_m_b2;
	        av_economic_m_b2 = economic_m_b2;
	        av_local_m_b2 = local_m_b2;
	        av_business_e_b2 = business_e_b2;
	        av_economic_e_b2 = economic_e_b2;
	        av_local_e_b2 = local_e_b2;

	        av_business_m_b3 = business_m_b3;
	        av_economic_m_b3 = economic_m_b3;
	        av_local_m_b3 = local_m_b3;
	        av_business_e_b3 = business_e_b3;
	        av_economic_e_b3 = economic_e_b3;
	        av_local_e_b3 = local_e_b3;

	        av_business_m_b4 = business_m_b4;
	        av_economic_m_b4 = economic_m_b4;
	        av_local_m_b4 = local_m_b4;
	        av_business_e_b4 = business_e_b4;
	        av_economic_e_b4 = economic_e_b4;
	        av_local_e_b4 = local_e_b4;
	    }

	    public String toString() {
	        return business_m_b1 + "#" + business_e_b1 + "#" + economic_m_b1 + "#"
	                + economic_e_b1 + "#" + local_m_b1 + "#" + local_e_b1
	                + business_m_b2 + "#" + business_e_b2 + "#" + economic_m_b2 + "#"
	                + economic_e_b2 + "#" + local_m_b2 + "#" + local_e_b2
	                + business_m_b3 + "#" + business_e_b3 + "#" + economic_m_b3 + "#"
	                + economic_e_b3 + "#" + local_m_b3 + "#" + local_e_b3
	                + business_m_b4 + "#" + business_e_b4 + "#" + economic_m_b4 + "#"
	                + economic_e_b4 + "#" + local_m_b4 + "#" + local_e_b4;
	    }

	    public Buss(String data) {
	        String rows[] = data.split("#");
	        business_m_b1 = Integer.parseInt(rows[0]);
	        economic_m_b1 = Integer.parseInt(rows[1]);
	        local_m_b1 = Integer.parseInt(rows[2]);
	        business_e_b1 = Integer.parseInt(rows[3]);
	        economic_e_b1 = Integer.parseInt(rows[4]);
	        local_e_b1 = Integer.parseInt(rows[5]);

	        business_m_b2 = Integer.parseInt(rows[6]);
	        economic_m_b2 = Integer.parseInt(rows[7]);
	        local_m_b2 = Integer.parseInt(rows[8]);
	        business_e_b2 = Integer.parseInt(rows[9]);
	        economic_e_b2 = Integer.parseInt(rows[10]);
	        local_e_b2 = Integer.parseInt(rows[11]);

	        business_m_b3 = Integer.parseInt(rows[12]);
	        economic_m_b3 = Integer.parseInt(rows[13]);
	        local_m_b3 = Integer.parseInt(rows[14]);
	        business_e_b3 = Integer.parseInt(rows[15]);
	        economic_e_b3 = Integer.parseInt(rows[16]);
	        local_e_b3 = Integer.parseInt(rows[17]);

	        business_m_b4 = Integer.parseInt(rows[18]);
	        economic_m_b4 = Integer.parseInt(rows[19]);
	        local_m_b4 = Integer.parseInt(rows[20]);
	        business_e_b4 = Integer.parseInt(rows[21]);
	        economic_e_b4 = Integer.parseInt(rows[22]);
	        local_e_b4 = Integer.parseInt(rows[23]);
	    }

	    static {
	        try {
	            business_m_b1 = readSeats("C:\\Users\\PC\\Desktop\\BUS 1 MORNING_B.txt", 0);
	            business_e_b1 = readSeats("C:\\Users\\PC\\Desktop\\BUS 1 EVENING_B.txt", 1);
	            economic_m_b1 = readSeats("C:\\Users\\PC\\Desktop\\BUS 1 MORNING_E.txt", 2);
	            economic_e_b1 = readSeats("C:\\Users\\PC\\Desktop\\BUS 1 EVENING_E.txt", 3);
	            local_m_b1 = readSeats("C:\\Users\\PC\\Desktop\\BUS 1 MORNING_L.txt", 4);
	            local_e_b1 = readSeats("C:\\Users\\PC\\Desktop\\BUS 1 EVENING_L.txt", 5);

	            business_m_b2 = readSeats("C:\\Users\\PC\\Desktop\\BUS 2 MORNING_B.txt", 6);
	            business_e_b2 = readSeats("C:\\Users\\PC\\Desktop\\BUS 2 EVENING_B.txt", 7);
	            economic_m_b2 = readSeats("C:\\Users\\PC\\Desktop\\BUS 2 MORNING_E.txt", 8);
	            economic_e_b2 = readSeats("C:\\Users\\PC\\Desktop\\BUS 2 EVENING_E.txt", 9);
	            local_m_b2 = readSeats("C:\\Users\\PC\\Desktop\\BUS 2 MORNING_L.txt", 10);
	            local_e_b2 = readSeats("C:\\Users\\PC\\Desktop\\BUS 2 EVENING_L.txt", 11);

	            business_m_b3 = readSeats("C:\\Users\\PC\\Desktop\\BUS 3 MORNING_B.txt", 12);
	            business_e_b3 = readSeats("C:\\Users\\PC\\Desktop\\BUS 3 EVENING_B.txt", 13);
	            economic_m_b3 = readSeats("C:\\Users\\PC\\Desktop\\BUS 3 MORNING_E.txt", 14);
	            economic_e_b3 = readSeats("C:\\Users\\PC\\Desktop\\BUS 3 EVENING_E.txt", 15);
	            local_m_b3 = readSeats("C:\\Users\\PC\\Desktop\\BUS 3 MORNING_L.txt", 16);
	            local_e_b3 = readSeats("C:\\Users\\PC\\Desktop\\BUS 3 EVENING_L.txt", 17);

	            business_m_b4 = readSeats("C:\\Users\\PC\\Desktop\\BUS 4 MORNING_B.txt", 18);
	            business_e_b4 = readSeats("C:\\Users\\PC\\Desktop\\BUS 4 EVENING_B.txt", 19);
	            economic_m_b4 = readSeats("C:\\Users\\PC\\Desktop\\BUS 4 MORNING_E.txt", 20);
	            economic_e_b4 = readSeats("C:\\Users\\PC\\Desktop\\BUS 4 EVENING_E.txt", 21);
	            local_m_b4 = readSeats("C:\\Users\\PC\\Desktop\\BUS 4 MORNING_L.txt", 22);
	            local_e_b4 = readSeats("C:\\Users\\PC\\Desktop\\BUS 4 EVENING_L.txt", 23);
	        } catch (IOException e) {
	           // System.out.println("Error reading file: " + e.getMessage());
	        } catch (NumberFormatException e) {
	            //System.out.println("Error parsing number: " + e.getMessage());
	        }
	    }

	    private static int readSeats(String filePath, int seatType) throws IOException {
	        List<String> lines = Files.readAllLines(Paths.get(filePath));
	        if (lines.isEmpty()) {
	            throw new NumberFormatException("File " + filePath + " is empty");
	        }
	        try {
	            return Integer.parseInt(lines.get(0));
	        } catch (NumberFormatException e) {
	            throw new NumberFormatException("Invalid number in file " + filePath + ": " + lines.get(0));
	        }
	    }
	}


